$('img').click(function() {
  $(this).hide();
});

$('button.restore').click(function() {
  location.reload();
})